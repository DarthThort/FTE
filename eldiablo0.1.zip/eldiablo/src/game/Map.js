class Map {
    constructor(width, height) {
        this.width = width;
        this.height = height;
        this.tiles = []; // 2D array
        this.generate();
    }

    generate() {
        // Simple random generation for now
        for (let x = 0; x < this.width; x++) {
            this.tiles[x] = [];
            for (let y = 0; y < this.height; y++) {
                // 0 = floor, 1 = wall (border)
                if (x === 0 || x === this.width - 1 || y === 0 || y === this.height - 1) {
                    this.tiles[x][y] = 1;
                } else {
                    this.tiles[x][y] = Math.random() > 0.9 ? 1 : 0; // 10% chance of obstacle
                }
            }
        }
    }

    spawnEnemies(count) {
        const enemies = [];
        for (let i = 0; i < count; i++) {
            let x, y;
            do {
                x = Math.floor(Math.random() * this.width);
                y = Math.floor(Math.random() * this.height);
            } while (!this.isWalkable(x, y));

            // Import Enemy dynamically or pass it in? 
            // Better to return positions or let Game handle creation.
            // For simplicity, let's return a list of positions.
            enemies.push({ x, y });
        }
        return enemies;
    }

    draw(renderer, cameraX, cameraY) {
        // Draw only visible tiles (optimization is in renderer, but we can loop smarter here too if needed)
        // For now, loop all
        for (let x = 0; x < this.width; x++) {
            for (let y = 0; y < this.height; y++) {
                const tile = this.tiles[x][y];
                const color = tile === 1 ? '#444' : '#222';
                // If wall, maybe draw it taller? For now just color diff
                if (tile === 1) {
                    renderer.drawRectIso(x, y, 1, 1, '#555', 0, cameraX, cameraY);
                } else {
                    renderer.drawTile(x, y, color, cameraX, cameraY);
                }
            }
        }
    }

    isWalkable(x, y) {
        if (x < 0 || x >= this.width || y < 0 || y >= this.height) return false;
        return this.tiles[Math.floor(x)][Math.floor(y)] === 0;
    }
}
