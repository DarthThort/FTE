class Player extends Entity {
    constructor(x, y) {
        super(x, y);
        this.color = '#0f0';
        this.speed = 5;

        // Stats
        this.baseStats = {
            strength: 10,
            dexterity: 10,
            intelligence: 10,
            vitality: 10
        };

        this.stats = { ...this.baseStats };
        this.hp = 100;
        this.maxHp = 100;
        this.level = 1;
        this.xp = 0;
        this.nextLevelXp = 100;

        this.inventory = [];
        this.equipment = {
            weapon: null,
            armor: null
        };

        this.recalcStats();
    }

    recalcStats() {
        this.stats = { ...this.baseStats };

        // Add equipment stats
        if (this.equipment.weapon) {
            for (let key in this.equipment.weapon.stats) {
                if (this.stats[key] !== undefined) this.stats[key] += this.equipment.weapon.stats[key];
            }
        }
        if (this.equipment.armor) {
            for (let key in this.equipment.armor.stats) {
                if (this.stats[key] !== undefined) this.stats[key] += this.equipment.armor.stats[key];
            }
        }

        this.maxHp = this.stats.vitality * 10;
        // Heal up on recalc? No, maybe just clamp
        if (this.hp > this.maxHp) this.hp = this.maxHp;
    }

    gainXp(amount) {
        this.xp += amount;
        if (this.xp >= this.nextLevelXp) {
            this.levelUp();
        }
    }

    levelUp() {
        this.level++;
        this.xp -= this.nextLevelXp;
        this.nextLevelXp = Math.floor(this.nextLevelXp * 1.5);

        // Stat increase
        this.baseStats.strength += 2;
        this.baseStats.dexterity += 2;
        this.baseStats.vitality += 2;
        this.baseStats.intelligence += 2;

        this.recalcStats();
        this.hp = this.maxHp; // Full heal
        console.log(`Level Up! Now level ${this.level}`);
    }

    equip(item) {
        if (item.type === 'weapon') {
            if (this.equipment.weapon) this.inventory.push(this.equipment.weapon);
            this.equipment.weapon = item;
        } else if (item.type === 'armor') {
            if (this.equipment.armor) this.inventory.push(this.equipment.armor);
            this.equipment.armor = item;
        }
        this.recalcStats();
    }

    update(dt, input) {
        const moveSpeed = this.speed * dt;
        let dx = 0;
        let dy = 0;

        // Screen Up (W) -> Decrease both X and Y (Grid North)
        if (input.isDown('KeyW')) {
            dx -= moveSpeed;
            dy -= moveSpeed;
        }
        // Screen Down (S) -> Increase both X and Y (Grid South)
        if (input.isDown('KeyS')) {
            dx += moveSpeed;
            dy += moveSpeed;
        }
        // Screen Left (A) -> Decrease X, Increase Y (Grid West)
        if (input.isDown('KeyA')) {
            dx -= moveSpeed;
            dy += moveSpeed;
        }
        // Screen Right (D) -> Increase X, Decrease Y (Grid East)
        if (input.isDown('KeyD')) {
            dx += moveSpeed;
            dy -= moveSpeed;
        }

        // Normalize if moving in multiple directions (e.g. W+D)
        // If we just add them up, W+D would be (dx=0, dy=-2*speed), which is length 2*speed.
        // We want constant speed.
        if (dx !== 0 || dy !== 0) {
            const dist = Math.sqrt(dx * dx + dy * dy);
            // We want the total distance moved this frame to be moveSpeed (or close to it)
            // But wait, moveSpeed is already scaled by dt.
            // If we press W, dist is sqrt(speed^2 + speed^2) = speed * 1.414
            // So single key press is already "fast" because we are moving on both axes.
            // We should scale the input vector to length 1, then multiply by moveSpeed.

            // Let's recalculate based on input direction vector first
            let inputX = 0;
            let inputY = 0;

            if (input.isDown('KeyW')) { inputX -= 1; inputY -= 1; }
            if (input.isDown('KeyS')) { inputX += 1; inputY += 1; }
            if (input.isDown('KeyA')) { inputX -= 1; inputY += 1; }
            if (input.isDown('KeyD')) { inputX += 1; inputY -= 1; }

            if (inputX !== 0 || inputY !== 0) {
                const len = Math.sqrt(inputX * inputX + inputY * inputY);
                inputX /= len;
                inputY /= len;

                dx = inputX * moveSpeed;
                dy = inputY * moveSpeed;
            } else {
                dx = 0;
                dy = 0;
            }
        }

        this.x += dx;
        this.y += dy;
    }
}
