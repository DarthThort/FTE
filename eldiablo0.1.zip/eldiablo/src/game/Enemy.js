class Enemy extends Entity {
    constructor(x, y, type = 'minion') {
        super(x, y);
        this.type = type;
        this.color = '#f00';
        this.speed = 2;
        this.aggroRange = 8;

        this.stats = {
            hp: 20,
            maxHp: 20,
            damage: 5,
            xpValue: 10
        };

        if (type === 'boss') {
            this.color = '#90f';
            this.width = 1.5;
            this.height = 1.5;
            this.stats.hp = 100;
            this.stats.maxHp = 100;
            this.stats.damage = 15;
            this.stats.xpValue = 100;
            this.speed = 3;
        }
    }

    update(dt, player, map) {
        // Simple AI: Move towards player if in range
        const dist = Math.hypot(player.x - this.x, player.y - this.y);

        if (dist < this.aggroRange && dist > 0.5) {
            const dx = player.x - this.x;
            const dy = player.y - this.y;

            // Normalize
            const len = Math.sqrt(dx * dx + dy * dy);
            const moveX = (dx / len) * this.speed * dt;
            const moveY = (dy / len) * this.speed * dt;

            // Try move X
            if (map.isWalkable(this.x + moveX, this.y)) {
                this.x += moveX;
            }
            // Try move Y
            if (map.isWalkable(this.x, this.y + moveY)) {
                this.y += moveY;
            }
        }
    }
}
