class Item {
    constructor(name, type, stats) {
        this.name = name;
        this.type = type; // 'weapon', 'armor'
        this.stats = stats; // { strength: 1, damage: 2, etc }
        this.x = 0;
        this.y = 0;
        this.color = '#ff0'; // Gold for items
    }

    static generate(level) {
        const types = ['weapon', 'armor'];
        const type = types[Math.floor(Math.random() * types.length)];

        let name = '';
        let stats = {};

        if (type === 'weapon') {
            name = 'Laser Sword';
            stats.damage = Math.floor(Math.random() * 5) + level * 2;
            stats.strength = Math.floor(Math.random() * 2) + level;
        } else {
            name = 'Nano Armor';
            stats.defense = Math.floor(Math.random() * 3) + level;
            stats.vitality = Math.floor(Math.random() * 2) + level;
        }

        return new Item(name, type, stats);
    }

    draw(renderer, cameraX, cameraY) {
        // Draw item as a small box
        renderer.drawRectIso(this.x, this.y, 0.4, 0.4, this.color, 0, cameraX, cameraY);
    }
}
