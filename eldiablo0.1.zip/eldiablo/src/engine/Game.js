class Game {
    constructor(canvas) {
        this.input = new Input();
        this.renderer = new Renderer(canvas);
        this.lastTime = 0;

        this.map = new Map(50, 50);
        this.player = new Player(25, 25); // Start in middle
        this.enemies = [];
        this.items = [];

        this.spawnEnemies();

        // UI Elements
        this.uiHpVal = document.getElementById('hp-val');
        this.uiHpMax = document.getElementById('hp-max');
        this.uiLvlVal = document.getElementById('lvl-val');
        this.uiMessages = document.getElementById('messages');
    }

    spawnEnemies() {
        const positions = this.map.spawnEnemies(20);
        positions.forEach(pos => {
            // Ensure not too close to player
            if (Math.hypot(pos.x - this.player.x, pos.y - this.player.y) > 5) {
                this.enemies.push(new Enemy(pos.x, pos.y));
            }
        });

        // Add a boss
        const bossPos = this.map.spawnEnemies(1)[0];
        this.enemies.push(new Enemy(bossPos.x, bossPos.y, 'boss'));
    }

    start() {
        requestAnimationFrame((time) => this.loop(time));
    }

    loop(time) {
        const dt = (time - this.lastTime) / 1000;
        this.lastTime = time;

        this.update(dt);
        this.draw();
        this.updateUI();

        this.input.update();
        requestAnimationFrame((time) => this.loop(time));
    }

    update(dt) {
        // Store old position for collision
        const oldX = this.player.x;
        const oldY = this.player.y;

        this.player.update(dt, this.input);

        // Simple collision check
        if (!this.map.isWalkable(this.player.x, this.player.y)) {
            this.player.x = oldX;
            this.player.y = oldY;
        }

        // Update enemies
        this.enemies.forEach(enemy => {
            enemy.update(dt, this.player, this.map);
        });

        // Combat: Player Attack
        if (this.input.isPressed('Space')) {
            this.playerAttack();
        }

        // Item Pickup
        this.items.forEach((item, index) => {
            const dist = Math.hypot(item.x - this.player.x, item.y - this.player.y);
            if (dist < 1) {
                // Auto pickup and equip for now (simple)
                this.player.equip(item);
                this.items.splice(index, 1);
                this.showMessage(`Picked up ${item.name}!`);
            }
        });

        // Cleanup dead enemies
        this.enemies = this.enemies.filter(e => e.stats.hp > 0);
    }

    playerAttack() {
        // Simple AoE around player
        const range = 2;
        this.enemies.forEach(enemy => {
            const dist = Math.hypot(enemy.x - this.player.x, enemy.y - this.player.y);
            if (dist <= range) {
                // Calculate damage based on player stats + weapon
                let dmg = this.player.stats.strength;
                if (this.player.equipment.weapon) dmg += this.player.equipment.weapon.stats.damage || 0;

                enemy.stats.hp -= dmg;
                console.log(`Hit enemy! HP: ${enemy.stats.hp}`);

                // Knockback
                const dx = enemy.x - this.player.x;
                const dy = enemy.y - this.player.y;
                enemy.x += dx * 0.5;
                enemy.y += dy * 0.5;

                if (enemy.stats.hp <= 0) {
                    this.onEnemyDeath(enemy);
                }
            }
        });
    }

    onEnemyDeath(enemy) {
        this.player.gainXp(enemy.stats.xpValue);
        this.showMessage(`Killed ${enemy.type}! +${enemy.stats.xpValue} XP`);

        // Drop loot
        if (Math.random() > 0.5) { // 50% drop rate
            const item = Item.generate(this.player.level);
            item.x = enemy.x;
            item.y = enemy.y;
            this.items.push(item);
        }
    }

    updateUI() {
        this.uiHpVal.innerText = this.player.hp;
        this.uiHpMax.innerText = this.player.maxHp;
        this.uiLvlVal.innerText = this.player.level;
    }

    showMessage(msg) {
        this.uiMessages.innerText = msg;
        setTimeout(() => {
            if (this.uiMessages.innerText === msg) this.uiMessages.innerText = '';
        }, 2000);
    }

    draw() {
        this.renderer.clear();

        // Camera follows player
        const cameraX = this.player.x;
        const cameraY = this.player.y;

        this.map.draw(this.renderer, cameraX, cameraY);

        this.items.forEach(item => item.draw(this.renderer, cameraX, cameraY));
        this.enemies.forEach(enemy => enemy.draw(this.renderer, cameraX, cameraY));

        this.player.draw(this.renderer, cameraX, cameraY);
    }
}
