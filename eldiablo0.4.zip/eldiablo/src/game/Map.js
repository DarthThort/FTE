class Map {
    constructor(width, height) {
        this.width = width;
        this.height = height;
        this.tiles = [];
        this.rooms = [];
        this.decorations = [];

        for (let y = 0; y < height; y++) {
            this.tiles[y] = [];
            for (let x = 0; x < width; x++) {
                this.tiles[y][x] = 0;
            }
        }

        this.generateDungeon();
    }

    generateDungeon() {
        const numRooms = 10;
        let attempts = 0;
        const maxAttempts = 100;

        while (this.rooms.length < numRooms && attempts < maxAttempts) {
            attempts++;
            const width = 5 + Math.floor(Math.random() * 5);
            const height = 5 + Math.floor(Math.random() * 5);
            const x = 1 + Math.floor(Math.random() * (this.width - width - 2));
            const y = 1 + Math.floor(Math.random() * (this.height - height - 2));

            const newRoom = { x, y, width, height };
            let overlaps = false;

            for (let room of this.rooms) {
                if (this.roomsOverlap(newRoom, room)) {
                    overlaps = true;
                    break;
                }
            }

            if (!overlaps) {
                this.createRoom(newRoom);

                if (this.rooms.length > 0) {
                    const prevRoom = this.rooms[this.rooms.length - 1];
                    this.createCorridor(prevRoom, newRoom);
                }

                this.rooms.push(newRoom);
            }
        }

        console.log(`Generated ${this.rooms.length} rooms`);
    }

    roomsOverlap(room1, room2) {
        return room1.x < room2.x + room2.width + 1 &&
            room1.x + room1.width + 1 > room2.x &&
            room1.y < room2.y + room2.height + 1 &&
            room1.y + room1.height + 1 > room2.y;
    }

    createRoom(room) {
        for (let y = room.y; y < room.y + room.height; y++) {
            for (let x = room.x; x < room.x + room.width; x++) {
                if (x >= 0 && x < this.width && y >= 0 && y < this.height) {
                    this.tiles[y][x] = 1;
                }
            }
        }
    }

    createCorridor(room1, room2) {
        const x1 = Math.floor(room1.x + room1.width / 2);
        const y1 = Math.floor(room1.y + room1.height / 2);
        const x2 = Math.floor(room2.x + room2.width / 2);
        const y2 = Math.floor(room2.y + room2.height / 2);

        if (Math.random() < 0.5) {
            this.createHCorridor(x1, x2, y1);
            this.createVCorridor(y1, y2, x2);
        } else {
            this.createVCorridor(y1, y2, x1);
            this.createHCorridor(x1, x2, y2);
        }
    }

    createHCorridor(x1, x2, y) {
        const minX = Math.min(x1, x2);
        const maxX = Math.max(x1, x2);
        for (let x = minX; x <= maxX; x++) {
            if (x >= 0 && x < this.width && y >= 0 && y < this.height) {
                this.tiles[y][x] = 1;
            }
        }
    }

    createVCorridor(y1, y2, x) {
        const minY = Math.min(y1, y2);
        const maxY = Math.max(y1, y2);
        for (let y = minY; y <= maxY; y++) {
            if (x >= 0 && x < this.width && y >= 0 && y < this.height) {
                this.tiles[y][x] = 1;
            }
        }
    }

    isWalkable(x, y) {
        const tileX = Math.floor(x);
        const tileY = Math.floor(y);

        if (tileX < 0 || tileX >= this.width || tileY < 0 || tileY >= this.height) {
            return false;
        }

        return this.tiles[tileY][tileX] === 1;
    }

    isWalkableWithHitbox(x, y) {
        return this.isWalkable(x, y);
    }

    spawnEnemies(count) {
        const spawns = [];
        if (this.rooms.length === 0) return spawns;

        for (let i = 0; i < count; i++) {
            const room = this.rooms[Math.floor(Math.random() * this.rooms.length)];
            const x = room.x + 1 + Math.floor(Math.random() * Math.max(1, room.width - 2));
            const y = room.y + 1 + Math.floor(Math.random() * Math.max(1, room.height - 2));
            spawns.push({ x, y });
        }
        return spawns;
    }

    spawnStairs() {
        if (this.rooms.length === 0) return { x: 25, y: 25 };

        const room = this.rooms[this.rooms.length - 1];
        const x = room.x + Math.floor(room.width / 2);
        const y = room.y + Math.floor(room.height / 2);
        return { x, y };
    }

    draw(renderer, cameraX, cameraY, stairs) {
        const minX = Math.floor(cameraX - 15);
        const maxX = Math.ceil(cameraX + 15);
        const minY = Math.floor(cameraY - 15);
        const maxY = Math.ceil(cameraY + 15);

        for (let y = Math.max(0, minY); y < Math.min(this.height, maxY); y++) {
            for (let x = Math.max(0, minX); x < Math.min(this.width, maxX); x++) {
                if (this.tiles[y][x] === 1) {
                    this.drawSpaceshipFloor(renderer, x, y, cameraX, cameraY);
                } else {
                    this.drawSpaceshipWall(renderer, x, y, cameraX, cameraY);
                }
            }
        }

        if (stairs) {
            this.drawTeleporter(renderer, stairs.x, stairs.y, cameraX, cameraY);
        }
    }

    drawSpaceshipFloor(renderer, x, y, cameraX, cameraY) {
        const pos = renderer.isoToScreen(x, y, cameraX, cameraY);
        const ctx = renderer.ctx;
        const tw = renderer.tileWidth;
        const th = renderer.tileHeight;

        const gradient = ctx.createLinearGradient(pos.x - tw, pos.y, pos.x + tw, pos.y + th * 2);
        gradient.addColorStop(0, '#1a2332');
        gradient.addColorStop(0.5, '#2a3342');
        gradient.addColorStop(1, '#1a2332');

        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.moveTo(pos.x, pos.y);
        ctx.lineTo(pos.x + tw, pos.y + th);
        ctx.lineTo(pos.x, pos.y + th * 2);
        ctx.lineTo(pos.x - tw, pos.y + th);
        ctx.closePath();
        ctx.fill();

        ctx.strokeStyle = '#0a1520';
        ctx.lineWidth = 1;
        ctx.stroke();

        if ((x + y) % 4 === 0) {
            ctx.strokeStyle = '#3a4a5a';
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(pos.x, pos.y + th);
            ctx.lineTo(pos.x, pos.y + th * 1.5);
            ctx.stroke();
        }
    }

    drawSpaceshipWall(renderer, x, y, cameraX, cameraY) {
        const pos = renderer.isoToScreen(x, y, cameraX, cameraY);
        const ctx = renderer.ctx;
        const tw = renderer.tileWidth;
        const th = renderer.tileHeight;

        // Pared plana simple con gradiente oscuro
        const gradient = ctx.createLinearGradient(pos.x - tw, pos.y, pos.x + tw, pos.y + th * 2);
        gradient.addColorStop(0, '#0a0f1a');
        gradient.addColorStop(0.3, '#151a25');
        gradient.addColorStop(0.7, '#0f1420');
        gradient.addColorStop(1, '#050810');

        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.moveTo(pos.x, pos.y);
        ctx.lineTo(pos.x + tw, pos.y + th);
        ctx.lineTo(pos.x, pos.y + th * 2);
        ctx.lineTo(pos.x - tw, pos.y + th);
        ctx.closePath();
        ctx.fill();

        // Borde del tile
        ctx.strokeStyle = '#05080d';
        ctx.lineWidth = 1;
        ctx.stroke();

        // Detectar paredes adyacentes a suelo para añadir decoración
        const hasFloorAbove = y > 0 && this.tiles[y - 1][x] === 1;
        const hasFloorBelow = y < this.height - 1 && this.tiles[y + 1][x] === 1;
        const hasFloorLeft = x > 0 && this.tiles[y][x - 1] === 1;
        const hasFloorRight = x < this.width - 1 && this.tiles[y][x + 1] === 1;

        // Solo dibujar detalles en paredes que bordean suelo
        if (hasFloorAbove || hasFloorBelow || hasFloorLeft || hasFloorRight) {
            // Panel metálico en perspectiva isométrica
            ctx.fillStyle = '#1a2535';
            ctx.beginPath();
            ctx.moveTo(pos.x, pos.y + th * 0.4);
            ctx.lineTo(pos.x + tw * 0.6, pos.y + th * 0.8);
            ctx.lineTo(pos.x, pos.y + th * 1.2);
            ctx.lineTo(pos.x - tw * 0.6, pos.y + th * 0.8);
            ctx.closePath();
            ctx.fill();

            // Bordes del panel
            ctx.strokeStyle = '#2a3545';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(pos.x, pos.y + th * 0.4);
            ctx.lineTo(pos.x + tw * 0.6, pos.y + th * 0.8);
            ctx.lineTo(pos.x, pos.y + th * 1.2);
            ctx.lineTo(pos.x - tw * 0.6, pos.y + th * 0.8);
            ctx.closePath();
            ctx.stroke();

            // Líneas horizontales en perspectiva (rejillas)
            ctx.strokeStyle = '#0a1520';
            ctx.lineWidth = 1;
            for (let i = 0; i < 3; i++) {
                const offset = i * 10;
                ctx.beginPath();
                ctx.moveTo(pos.x - tw * 0.4, pos.y + th * 0.6 + offset);
                ctx.lineTo(pos.x + tw * 0.4, pos.y + th * 0.8 + offset);
                ctx.stroke();
            }

            // Luz indicadora (solo algunas paredes)
            if ((x * 7 + y * 13) % 11 === 0) {
                ctx.fillStyle = '#00ff88';
                ctx.shadowBlur = 8;
                ctx.shadowColor = '#00ff88';
                ctx.beginPath();
                ctx.moveTo(pos.x, pos.y + th * 0.5);
                ctx.lineTo(pos.x + 8, pos.y + th * 0.5 + 4);
                ctx.lineTo(pos.x, pos.y + th * 0.5 + 8);
                ctx.lineTo(pos.x - 8, pos.y + th * 0.5 + 4);
                ctx.closePath();
                ctx.fill();
                ctx.shadowBlur = 0;
            }
        }
    }

    drawTeleporter(renderer, x, y, cameraX, cameraY) {
        const pos = renderer.isoToScreen(x, y, cameraX, cameraY);
        const ctx = renderer.ctx;
        const tw = renderer.tileWidth;
        const th = renderer.tileHeight;
        const time = Date.now() / 1000;
        const pulse = Math.sin(time * 3) * 0.3 + 0.7;

        ctx.save();
        ctx.fillStyle = `rgba(0, 255, 255, ${pulse * 0.3})`;
        ctx.shadowBlur = 20;
        ctx.shadowColor = '#0ff';
        ctx.beginPath();
        ctx.ellipse(pos.x, pos.y + th, tw * 0.6, th * 0.3, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        ctx.fillStyle = '#1a4a5a';
        ctx.beginPath();
        ctx.moveTo(pos.x, pos.y);
        ctx.lineTo(pos.x + tw / 2, pos.y + th / 2);
        ctx.lineTo(pos.x, pos.y + th);
        ctx.lineTo(pos.x - tw / 2, pos.y + th / 2);
        ctx.closePath();
        ctx.fill();

        ctx.strokeStyle = `rgba(0, 255, 255, ${pulse})`;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.ellipse(pos.x, pos.y + th, tw * 0.4, th * 0.2, 0, 0, Math.PI * 2);
        ctx.stroke();

        ctx.strokeStyle = `rgba(0, 200, 255, ${pulse * 0.7})`;
        ctx.beginPath();
        ctx.ellipse(pos.x, pos.y + th, tw * 0.5, th * 0.25, 0, 0, Math.PI * 2);
        ctx.stroke();
    }
}
