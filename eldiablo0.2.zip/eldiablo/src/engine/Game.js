class Game {
    constructor(canvas) {
        this.input = new Input();
        this.renderer = new Renderer(canvas);
        this.sound = new Sound();
        this.lastTime = 0;

        this.currentLevel = 1;
        this.maxLevel = 10;

        this.map = new Map(50, 50);
        this.player = new Player(25, 25);
        this.enemies = [];
        this.items = [];
        this.effects = [];
        this.stairs = null;

        this.initLevel();

        this.uiHpVal = document.getElementById('hp-val');
        this.uiHpMax = document.getElementById('hp-max');
        this.uiLvlVal = document.getElementById('lvl-val');
        this.uiFloorVal = document.getElementById('floor-val');
        this.uiMessages = document.getElementById('messages');
    }

    initLevel() {
        this.enemies = [];
        this.items = [];

        const enemyCount = 10 + this.currentLevel * 2;
        this.spawnEnemies(enemyCount);

        if (this.currentLevel < this.maxLevel) {
            this.stairs = this.map.spawnStairs();
        } else {
            this.stairs = null;
        }
    }

    spawnEnemies(count) {
        const positions = this.map.spawnEnemies(count);
        positions.forEach(pos => {
            if (Math.hypot(pos.x - this.player.x, pos.y - this.player.y) > 5) {
                this.enemies.push(new Enemy(pos.x, pos.y));
            }
        });

        const bossCount = this.currentLevel === this.maxLevel ? 1 : Math.floor(this.currentLevel / 3);
        for (let i = 0; i < bossCount; i++) {
            const bossPos = this.map.spawnEnemies(1)[0];
            this.enemies.push(new Enemy(bossPos.x, bossPos.y, 'boss'));
        }
    }

    start() {
        requestAnimationFrame((time) => this.loop(time));
    }

    loop(time) {
        const dt = (time - this.lastTime) / 1000;
        this.lastTime = time;

        this.update(dt);
        this.draw();
        this.updateUI();

        this.input.update();
        requestAnimationFrame((time) => this.loop(time));
    }

    update(dt) {
        if (this.player.hp <= 0) {
            this.showMessage('GAME OVER! Refresh to restart.');
            return;
        }

        const oldX = this.player.x;
        const oldY = this.player.y;

        this.player.update(dt, this.input);

        if (!this.map.isWalkable(this.player.x, this.player.y)) {
            this.player.x = oldX;
            this.player.y = oldY;
        }

        if (this.stairs) {
            const distToStairs = Math.hypot(this.player.x - this.stairs.x, this.player.y - this.stairs.y);
            if (distToStairs < 1) {
                this.nextLevel();
            }
        }

        this.enemies.forEach(enemy => {
            enemy.update(dt, this.player, this.map);
        });

        this.effects.forEach(effect => effect.update(dt));
        this.effects = this.effects.filter(e => e.life > 0);

        if (this.input.isPressed('Space')) {
            this.playerAttack();
        }

        this.items.forEach((item, index) => {
            const dist = Math.hypot(item.x - this.player.x, item.y - this.player.y);
            if (dist < 1) {
                this.player.equip(item);
                this.items.splice(index, 1);
                this.showMessage(`Picked up ${item.name}!`);
            }
        });

        this.enemies = this.enemies.filter(e => e.stats.hp > 0);

        if (this.currentLevel === this.maxLevel && this.enemies.length === 0) {
            this.showMessage('YOU WIN! Final boss defeated!');
        }
    }

    nextLevel() {
        this.currentLevel++;
        if (this.currentLevel > this.maxLevel) {
            this.currentLevel = this.maxLevel;
            return;
        }

        this.showMessage(`Level ${this.currentLevel}!`);

        this.player.x = 25;
        this.player.y = 25;

        this.map = new Map(50, 50);
        this.initLevel();
    }

    playerAttack() {
        this.sound.playAttack();
        this.effects.push(new Effect(this.player.x, this.player.y, 'pulse'));

        const range = 2;
        this.enemies.forEach(enemy => {
            const dist = Math.hypot(enemy.x - this.player.x, enemy.y - this.player.y);
            if (dist <= range) {
                let dmg = this.player.stats.strength;
                if (this.player.equipment.weapon) dmg += this.player.equipment.weapon.stats.damage || 0;

                enemy.stats.hp -= dmg;
                this.sound.playHit();
                console.log(`Hit enemy! HP: ${enemy.stats.hp}`);

                const dx = enemy.x - this.player.x;
                const dy = enemy.y - this.player.y;
                enemy.x += dx * 0.5;
                enemy.y += dy * 0.5;

                if (enemy.stats.hp <= 0) {
                    this.onEnemyDeath(enemy);
                }
            }
        });
    }

    onEnemyDeath(enemy) {
        this.player.gainXp(enemy.stats.xpValue);
        this.showMessage(`Killed ${enemy.type}! +${enemy.stats.xpValue} XP`);

        if (Math.random() > 0.5) {
            const item = Item.generate(this.player.level);
            item.x = enemy.x;
            item.y = enemy.y;
            this.items.push(item);
        }
    }

    updateUI() {
        this.uiHpVal.innerText = Math.floor(this.player.hp);
        this.uiHpMax.innerText = this.player.maxHp;
        this.uiLvlVal.innerText = this.player.level;
        this.uiFloorVal.innerText = this.currentLevel;
    }

    showMessage(msg) {
        this.uiMessages.innerText = msg;
        setTimeout(() => {
            if (this.uiMessages.innerText === msg) this.uiMessages.innerText = '';
        }, 2000);
    }

    draw() {
        this.renderer.clear();

        const cameraX = this.player.x;
        const cameraY = this.player.y;

        this.map.draw(this.renderer, cameraX, cameraY, this.stairs);

        this.items.forEach(item => item.draw(this.renderer, cameraX, cameraY));
        this.enemies.forEach(enemy => enemy.draw(this.renderer, cameraX, cameraY));

        this.player.draw(this.renderer, cameraX, cameraY);

        this.effects.forEach(effect => effect.draw(this.renderer, cameraX, cameraY));
    }
}
