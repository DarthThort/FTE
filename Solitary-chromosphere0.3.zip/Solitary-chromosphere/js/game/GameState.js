class GameState {
    constructor() {
        this.credits = 1000;

        this.ship = {
            name: "Rusty Tub",
            type: "Frigate Class",
            health: 100,
            maxHealth: 100,
            shield: 50,
            maxShield: 50,
            cargo: 0,
            maxCargo: 50,
            maxCargo: 50,
            level: 1,
            jumpRange: 6, // Light Years
            layout: [
                [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 1, 2, 2, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 1, 2, 3, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 1, 2, 4, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 1, 1, 1, 1, 1, 2, 2, 2, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
                [0, 0, 1, 2, 2, 3, 2, 2, 2, 2, 2, 3, 2, 2, 1, 0, 0, 0, 0, 0],
                [0, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 0, 0, 0, 0],
                [0, 0, 1, 1, 1, 4, 1, 1, 4, 1, 1, 4, 1, 1, 1, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 1, 2, 1, 0, 2, 0, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 1, 2, 1, 0, 2, 0, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 1, 1, 1, 4, 1, 1, 4, 1, 1, 4, 1, 1, 1, 0, 0, 0, 0, 0],
                [0, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 0, 0, 0, 0],
                [0, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 0, 0, 0, 0],
                [0, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 0, 0, 0, 0],
                [0, 0, 1, 1, 1, 1, 1, 4, 4, 4, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 1, 2, 2, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 1, 2, 3, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            ],
            systems: [
                { x: 8, y: 2, id: 'bridge', name: 'Bridge Console', type: 'bridge', color: '#00f0ff' },
                { x: 8, y: 16, id: 'engines', name: 'Engine Control', type: 'engine', color: '#ff5500' },
                { x: 5, y: 5, id: 'weapons', name: 'Weapons Array', type: 'weapon', color: '#ff0055' },
                { x: 11, y: 5, id: 'shields', name: 'Shield Generator', type: 'shield', color: '#00ff55' }
            ],
            modules: [],
            crew: [],
            maxCrew: 6,
            fuel: 100,
            maxFuel: 100
        };

        this.inventory = [
            { id: 'fuel', name: 'Fuel Cells', quantity: 10, value: 50 },
            { id: 'rations', name: 'Rations', quantity: 20, value: 10 },
            { id: 'engine_mod_mk1', name: 'Engine Booster Mk1', quantity: 1, value: 200, type: 'module', systemType: 'engine' },
            { id: 'weapon_mod_laser', name: 'Pulse Laser', quantity: 1, value: 350, type: 'module', systemType: 'weapon' }
        ];

        this.port = {
            ships: [],
            crew: [],
            contracts: []
        };

        this.market = [
            { id: 'fuel', name: 'Fuel Cells', price: 55, stock: 100 },
            { id: 'rations', name: 'Rations', price: 12, stock: 200 },
            { id: 'scrap', name: 'Scrap Metal', price: 25, stock: 50 },
            { id: 'electronics', name: 'Microchips', price: 150, stock: 10 }
        ];

        // Star Systems (Sol + 10 nearest real systems)
        this.galaxy = null;
        this.currentSystem = null;
        this.currentPlanet = null;
        this.initializeGalaxy();

        this.generatePortContent();
        this.listeners = [];
        this.loadGame();
    }

    generatePortContent() {
        this.port.ships = [
            { id: 1, name: "Kestrel Class", type: "Frigate", cost: 1500, hull: 100, slots: 4, desc: "Versatile starter ship." },
            { id: 2, name: "Mantis Class", type: "Interceptor", cost: 800, hull: 60, slots: 2, desc: "Fast and deadly." },
            { id: 3, name: "Behemoth Class", type: "Hauler", cost: 2500, hull: 200, slots: 6, desc: "Heavy cargo transport." }
        ];

        this.port.crew = [
            {
                id: 1,
                name: "Bolt",
                species: "Human",
                gender: "Male",
                age: 32,
                role: "Engineer",
                health: 100,
                maxHealth: 100,
                morale: 85,
                cost: 150,
                skills: {
                    engineering: { level: 5, xp: 0, xpToNext: 100 },
                    piloting: { level: 2, xp: 0, xpToNext: 100 },
                    combat: { level: 1, xp: 0, xpToNext: 100 },
                    medical: { level: 1, xp: 0, xpToNext: 100 }
                },
                background: "Former military engineer turned freelancer."
            },
            {
                id: 2,
                name: "Nova",
                species: "Human",
                gender: "Female",
                age: 28,
                role: "Pilot",
                health: 100,
                maxHealth: 100,
                morale: 90,
                cost: 200,
                skills: {
                    piloting: { level: 7, xp: 0, xpToNext: 100 },
                    engineering: { level: 2, xp: 0, xpToNext: 100 },
                    combat: { level: 3, xp: 0, xpToNext: 100 },
                    medical: { level: 1, xp: 0, xpToNext: 100 }
                },
                background: "Ace pilot with racing history."
            },
            {
                id: 3,
                name: "Xar'thos",
                species: "Alien",
                gender: "Male",
                age: 45,
                role: "Gunner",
                health: 120,
                maxHealth: 120,
                morale: 75,
                cost: 180,
                skills: {
                    combat: { level: 6, xp: 0, xpToNext: 100 },
                    piloting: { level: 2, xp: 0, xpToNext: 100 },
                    engineering: { level: 1, xp: 0, xpToNext: 100 },
                    medical: { level: 1, xp: 0, xpToNext: 100 }
                },
                background: "Veteran soldier seeking new horizons."
            },
            {
                id: 4,
                name: "Dr. Chen",
                species: "Human",
                gender: "Female",
                age: 41,
                role: "Medic",
                health: 90,
                maxHealth: 90,
                morale: 95,
                cost: 220,
                skills: {
                    medical: { level: 8, xp: 0, xpToNext: 100 },
                    engineering: { level: 1, xp: 0, xpToNext: 100 },
                    piloting: { level: 1, xp: 0, xpToNext: 100 },
                    combat: { level: 2, xp: 0, xpToNext: 100 }
                },
                background: "Experienced field medic from the outer colonies."
            },
            {
                id: 5,
                name: "Rax",
                species: "Robot",
                gender: "N/A",
                age: 12,
                role: "Engineer",
                health: 150,
                maxHealth: 150,
                morale: 100,
                cost: 300,
                skills: {
                    engineering: { level: 9, xp: 50, xpToNext: 100 },
                    piloting: { level: 3, xp: 0, xpToNext: 100 },
                    combat: { level: 1, xp: 0, xpToNext: 100 },
                    medical: { level: 0, xp: 0, xpToNext: 100 }
                },
                background: "Advanced maintenance droid with adaptive learning."
            },
            {
                id: 6,
                name: "Luna Swift",
                species: "Human",
                gender: "Female",
                age: 24,
                role: "Pilot",
                health: 95,
                maxHealth: 95,
                morale: 88,
                cost: 160,
                skills: {
                    piloting: { level: 6, xp: 30, xpToNext: 100 },
                    combat: { level: 4, xp: 0, xpToNext: 100 },
                    engineering: { level: 1, xp: 0, xpToNext: 100 },
                    medical: { level: 1, xp: 0, xpToNext: 100 }
                },
                background: "Young hotshot pilot looking for adventure."
            },
            {
                id: 7,
                name: "Grimm",
                species: "Alien",
                gender: "Male",
                age: 52,
                role: "Gunner",
                health: 140,
                maxHealth: 140,
                morale: 70,
                cost: 190,
                skills: {
                    combat: { level: 8, xp: 80, xpToNext: 100 },
                    engineering: { level: 2, xp: 0, xpToNext: 100 },
                    piloting: { level: 3, xp: 0, xpToNext: 100 },
                    medical: { level: 1, xp: 0, xpToNext: 100 }
                },
                background: "Grizzled mercenary with countless battles under his belt."
            },
            {
                id: 8,
                name: "Kai",
                species: "Human",
                gender: "Male",
                age: 29,
                role: "Engineer",
                health: 100,
                maxHealth: 100,
                morale: 82,
                cost: 140,
                skills: {
                    engineering: { level: 4, xp: 60, xpToNext: 100 },
                    piloting: { level: 3, xp: 0, xpToNext: 100 },
                    combat: { level: 2, xp: 0, xpToNext: 100 },
                    medical: { level: 1, xp: 0, xpToNext: 100 }
                },
                background: "Self-taught mechanic from a backwater station."
            },
            {
                id: 9,
                name: "Zara",
                species: "Alien",
                gender: "Female",
                age: 35,
                role: "Medic",
                health: 85,
                maxHealth: 85,
                morale: 92,
                cost: 175,
                skills: {
                    medical: { level: 6, xp: 40, xpToNext: 100 },
                    engineering: { level: 2, xp: 0, xpToNext: 100 },
                    piloting: { level: 1, xp: 0, xpToNext: 100 },
                    combat: { level: 3, xp: 0, xpToNext: 100 }
                },
                background: "Compassionate healer with knowledge of alien biology."
            },
            {
                id: 10,
                name: "Ghost",
                species: "Human",
                gender: "Male",
                age: 38,
                role: "Pilot",
                health: 80,
                maxHealth: 80,
                morale: 65,
                cost: 250,
                skills: {
                    piloting: { level: 9, xp: 90, xpToNext: 100 },
                    combat: { level: 5, xp: 50, xpToNext: 100 },
                    engineering: { level: 2, xp: 0, xpToNext: 100 },
                    medical: { level: 1, xp: 0, xpToNext: 100 }
                },
                background: "Mysterious pilot who rarely speaks of their past."
            }
        ];

        this.port.contracts = [
            { id: 1, title: "Cargo Haul", description: "Deliver supplies to Sector 7.", reward: 500, difficulty: 1 },
            { id: 2, title: "Bounty Hunt", description: "Destroy the pirate vessel 'Red Skull'.", reward: 1200, difficulty: 3 },
            { id: 3, title: "Escort Duty", description: "Protect the mining convoy.", reward: 800, difficulty: 2 }
        ];
    }

    loadGame() {
        const savedData = localStorage.getItem('spaceSimSave');
        if (savedData) {
            try {
                const data = JSON.parse(savedData);
                this.credits = data.credits;
                this.ship = { ...this.ship, ...data.ship };
                this.port.crew = data.portCrew || this.port.crew;
                this.port.contracts = data.contracts || this.port.contracts;

                if (data.galaxy) {
                    this.galaxy = data.galaxy;
                    this.currentSystem = data.currentSystem || this.galaxy[0];
                    this.currentPlanet = data.currentPlanet || (this.currentSystem.planets && this.currentSystem.planets[0]);
                } else {
                    this.initializeGalaxy();
                }

                if (data.ship.crew) {
                    this.ship.crew = data.ship.crew.map(c => ({
                        ...c,
                        targetX: null,
                        targetY: null,
                        path: [],
                        state: 'idle',
                        wanderTimer: 0,
                        doorWaitTimer: 0
                    }));
                }
                console.log('Game Loaded');
            } catch (e) {
                console.error('Failed to load save:', e);
                this.initializeGalaxy();
            }
        } else {
            this.initializeGalaxy();
        }
    }

    saveGame() {
        const data = {
            credits: this.credits,
            ship: {
                ...this.ship,
                crew: this.ship.crew.map(c => ({
                    ...c,
                    targetX: null,
                    targetY: null,
                    path: [],
                    state: 'idle'
                }))
            },
            portCrew: this.port.crew,
            contracts: this.port.contracts,
            galaxy: this.galaxy,
            currentSystem: this.currentSystem,
            currentPlanet: this.currentPlanet
        };
        localStorage.setItem('spaceSimSave', JSON.stringify(data));
        console.log('Game Saved');
    }

    initializeGalaxy() {
        // Real Star Systems Data (Sol + 9 closest)
        const REAL_STARS = [
            { id: 'sol', name: 'Sol', x: 0, y: 0, type: 'Yellow Star', color: '#ffdd44', realDist: 0 },
            { id: 'alpha_centauri', name: 'Alpha Centauri', x: 4, y: 2, type: 'Binary System', color: '#ff88ff', realDist: 4.37 },
            { id: 'barnards_star', name: "Barnard's Star", x: -2, y: 5, type: 'Red Dwarf', color: '#ff4444', realDist: 5.96 },
            { id: 'wolf_359', name: 'Wolf 359', x: 6, y: -4, type: 'Red Dwarf', color: '#ff4444', realDist: 7.78 },
            { id: 'lalande_21185', name: 'Lalande 21185', x: -5, y: -6, type: 'Red Dwarf', color: '#ff4444', realDist: 8.29 },
            { id: 'sirius', name: 'Sirius', x: -3, y: 8, type: 'Blue Giant', color: '#4444ff', realDist: 8.6 },
            { id: 'luyten_726_8', name: 'Luyten 726-8', x: 8, y: 3, type: 'Binary System', color: '#ff88ff', realDist: 8.73 },
            { id: 'ross_154', name: 'Ross 154', x: 2, y: -9, type: 'Red Dwarf', color: '#ff4444', realDist: 9.68 },
            { id: 'ross_248', name: 'Ross 248', x: -9, y: 1, type: 'Red Dwarf', color: '#ff4444', realDist: 10.32 },
            { id: 'epsilon_eridani', name: 'Epsilon Eridani', x: 7, y: 7, type: 'Yellow Star', color: '#ffdd44', realDist: 10.52 }
        ];

        const systems = REAL_STARS.map(star => ({
            ...star,
            visited: star.id === 'sol',
            planets: [], // Will be populated below
            resources: Math.random() > 0.5 ? ['Iron', 'Ice'] : ['Gold', 'Titanium']
        }));

        // Populate Sol System
        const solSystem = systems.find(s => s.id === 'sol');
        solSystem.planets = [
            { id: 'mercury', name: 'Mercury', type: 'Barren', color: '#aaaaaa', distance: 30, hasStation: false },
            { id: 'venus', name: 'Venus', type: 'Toxic', color: '#eebb00', distance: 50, hasStation: false },
            { id: 'earth', name: 'Earth', type: 'Terran', color: '#00aaff', distance: 80, hasStation: true },
            { id: 'mars', name: 'Mars', type: 'Desert', color: '#ff4400', distance: 110, hasStation: true },
            { id: 'jupiter', name: 'Jupiter', type: 'Gas Giant', color: '#ddaa88', distance: 180, hasStation: false },
            { id: 'saturn', name: 'Saturn', type: 'Gas Giant', color: '#eecc88', distance: 240, hasStation: false },
            { id: 'uranus', name: 'Uranus', type: 'Ice Giant', color: '#88ffff', distance: 300, hasStation: false },
            { id: 'neptune', name: 'Neptune', type: 'Ice Giant', color: '#4444ff', distance: 360, hasStation: false }
        ];

        // Populate other systems procedurally
        systems.forEach(system => {
            if (system.id !== 'sol') {
                const numPlanets = Math.floor(Math.random() * 3) + 3; // 3-5 planets
                const planets = [];

                for (let i = 0; i < numPlanets; i++) {
                    planets.push({
                        id: `${system.id}_p${i}`,
                        name: `${system.name} ${['I', 'II', 'III', 'IV', 'V'][i]}`,
                        type: ['Barren', 'Desert', 'Ice', 'Terran', 'Gas Giant'][Math.floor(Math.random() * 5)],
                        color: ['#aaaaaa', '#ff4400', '#88ffff', '#00aaff', '#ddaa88'][Math.floor(Math.random() * 5)],
                        distance: 40 + (i * 50),
                        hasStation: false // Will be set below
                    });
                }

                // Ensure at least 2-3 stations per system
                const numStations = Math.floor(Math.random() * 2) + 2; // 2-3 stations
                const stationIndices = [];
                while (stationIndices.length < Math.min(numStations, planets.length)) {
                    const idx = Math.floor(Math.random() * planets.length);
                    if (!stationIndices.includes(idx)) {
                        stationIndices.push(idx);
                        planets[idx].hasStation = true;
                    }
                }

                system.planets = planets;
            }
        });

        this.galaxy = systems;
        this.currentSystem = solSystem;
        this.currentPlanet = solSystem.planets.find(p => p.id === 'earth'); // Start at Earth

        return systems;
    }

    subscribe(callback) {
        this.listeners.push(callback);
    }

    notify() {
        this.listeners.forEach(cb => cb(this));
    }

    updateCredits(amount) {
        this.credits += amount;
        this.saveGame();
        this.notify();
    }

    damageShip(amount) {
        this.ship.health = Math.max(0, this.ship.health - amount);
        this.saveGame();
        this.notify();
    }

    buyItem(itemId, amount) {
        const item = this.market.find(i => i.id === itemId);
        if (!item || item.stock < amount) return false;

        const cost = item.price * amount;
        if (this.credits < cost) return false;

        this.credits -= cost;
        item.stock -= amount;
        this.saveGame();
        this.notify();
        return true;
    }

    sellItem(itemId, amount) {
        this.saveGame();
        this.notify();
        return true;
    }

    uninstallSystem(system) {
        this.ship.systems = this.ship.systems.filter(s => s !== system);
        this.saveGame();
        this.notify();
    }

    installSystem(item, x, y) {
        if (this.ship.systems.find(s => s.x === x && s.y === y)) return false;

        this.ship.systems.push({
            x: x,
            y: y,
            id: item.systemType + '_' + Date.now(),
            name: item.name.replace(' Module', ''),
            type: item.systemType,
            color: this.getSystemColor(item.systemType)
        });

        // Remove from inventory if it exists there
        const inventoryIndex = this.inventory.findIndex(i => i.id === item.id);
        if (inventoryIndex > -1) {
            this.inventory.splice(inventoryIndex, 1);
        }

        this.saveGame();
        this.notify();
        return true;
    }

    toggleDoor(x, y) {
        const tile = this.ship.layout[y][x];
        if (tile === 4) {
            this.ship.layout[y][x] = 5;
        } else if (tile === 5) {
            this.ship.layout[y][x] = 4;
        }
        this.saveGame();
        this.notify();
    }

    travelToSystem(systemId) {
        const targetSystem = this.galaxy.find(s => s.id === systemId);
        if (!targetSystem) return { success: false, message: "System not found." };

        // Calculate distance
        const dx = targetSystem.x - this.currentSystem.x;
        const dy = targetSystem.y - this.currentSystem.y;
        // Simplified distance for grid, but realDist is for flavor/lore
        const distance = Math.sqrt(dx * dx + dy * dy);

        // Use realDist if available and jumping from Sol (or relative logic)
        // For now, let's use the grid distance as the mechanic

        if (distance > this.ship.jumpRange) {
            return { success: false, message: `Target out of jump range (${distance.toFixed(1)} LY > ${this.ship.jumpRange} LY)` };
        }

        this.currentSystem = targetSystem;
        this.currentPlanet = null; // Reset planet when jumping systems

        // Mark as visited
        targetSystem.visited = true;

        this.saveGame();
        this.notify();
        return { success: true, message: `Jumping to ${targetSystem.name}...` };
    }

    travelToPlanet(planetId) {
        const targetPlanet = this.currentSystem.planets.find(p => p.id === planetId);
        if (!targetPlanet) return { success: false, message: "Planet not found." };

        const fuelCost = 5; // Fixed cost for now
        if (this.ship.fuel < fuelCost) {
            return { success: false, message: "Insufficient fuel for planetary travel." };
        }

        this.ship.fuel -= fuelCost;
        this.currentPlanet = targetPlanet;

        this.saveGame();
        this.notify();
        return { success: true, message: `Traveling to ${targetPlanet.name}...` };
    }

    getSystemColor(type) {
        switch (type) {
            case 'bridge': return '#00f0ff';
            case 'engine': return '#ff5500';
            case 'weapon': return '#ff0055';
            case 'shield': return '#00ff55';
            default: return '#ffffff';
        }
    }

    hireCrew(crewId) {
        const crew = this.port.crew.find(c => c.id === crewId);
        if (!crew) return { success: false, message: 'Crew member not found!' };

        if (this.ship.crew.length >= this.ship.maxCrew) {
            return { success: false, message: 'Crew quarters are full!' };
        }

        if (this.credits < crew.cost) {
            return { success: false, message: 'Insufficient credits!' };
        }

        this.credits -= crew.cost;
        this.ship.crew.push({
            ...crew,
            x: 250,
            y: 160,
            targetX: null,
            targetY: null,
            path: [],
            speed: 1.5,
            state: 'idle',
            wanderTimer: 0,
            doorWaitTimer: 0
        });
        this.port.crew = this.port.crew.filter(c => c.id !== crewId);
        this.saveGame();
        this.notify();

        return { success: true, message: `${crew.name} has joined your crew!` };
    }

    assignCrewToSystem(crewId, systemId) {
        const crew = this.ship.crew.find(c => c.id === crewId);
        const system = this.ship.systems.find(s => s.id === systemId);

        if (!crew || !system) {
            return { success: false, message: 'Invalid crew or system!' };
        }

        if (system.assignedCrew) {
            return { success: false, message: 'System already has assigned crew!' };
        }

        system.assignedCrew = crew;
        crew.targetX = system.x * 32 + 16;
        crew.targetY = system.y * 32 + 16;
        crew.state = 'moving';
        crew.path = [];

        this.saveGame();
        this.notify();

        return { success: true, message: `${crew.name} assigned to ${system.name}` };
    }

    unassignCrewFromSystem(systemId) {
        const system = this.ship.systems.find(s => s.id === systemId);

        if (!system || !system.assignedCrew) {
            return { success: false, message: 'No crew assigned to this system!' };
        }

        const crew = system.assignedCrew;
        crew.targetX = null;
        crew.targetY = null;
        crew.state = 'idle';
        crew.path = [];
        crew.wanderTimer = 0;

        const crewName = system.assignedCrew.name;
        system.assignedCrew = null;
        this.saveGame();
        this.notify();

        return { success: true, message: `${crewName} unassigned` };
    }

    getRolePrimarySkill(role) {
        const skillMap = {
            'Engineer': 'engineering',
            'Pilot': 'piloting',
            'Gunner': 'combat',
            'Medic': 'medical'
        };
        return skillMap[role] || 'engineering';
    }

    updateCrewAI() {
        for (const crew of this.ship.crew) {
            if (crew.state === 'idle' && (!crew.targetX || !crew.targetY)) {
                if (!crew.wanderTimer || crew.wanderTimer <= 0) {
                    const wanderSpot = this.getRandomWalkablePosition();
                    if (wanderSpot) {
                        crew.targetX = wanderSpot.x * 32 + 16;
                        crew.targetY = wanderSpot.y * 32 + 16;
                        crew.state = 'wandering';
                        crew.path = [];
                    }
                    crew.wanderTimer = 3 + Math.random() * 2;
                }
                crew.wanderTimer -= 1 / 60;
            }

            if ((crew.state === 'moving' || crew.state === 'wandering') && crew.targetX !== null && crew.targetY !== null) {
                if (!crew.path || crew.path.length === 0) {
                    const startX = Math.floor(crew.x / 32);
                    const startY = Math.floor(crew.y / 32);
                    const targetX = Math.floor(crew.targetX / 32);
                    const targetY = Math.floor(crew.targetY / 32);

                    let path = this.findPath(startX, startY, targetX, targetY);
                    path = this.smoothPath(path);

                    crew.path = path.map(node => ({
                        x: node.x,
                        y: node.y,
                        offsetX: (Math.random() - 0.5) * 4,
                        offsetY: (Math.random() - 0.5) * 4
                    }));
                }

                if (crew.path && crew.path.length > 0) {
                    const nextNode = crew.path[0];
                    const nextX = nextNode.x * 32 + 16 + (nextNode.offsetX || 0);
                    const nextY = nextNode.y * 32 + 16 + (nextNode.offsetY || 0);

                    const dx = nextX - crew.x;
                    const dy = nextY - crew.y;
                    const distance = Math.sqrt(dx * dx + dy * dy);

                    // Check if next tile is a closed door
                    const nextTile = this.ship.layout[nextNode.y]?.[nextNode.x];

                    if (nextTile === 4 && distance < 40) {
                        // Initialize timer if not present
                        if (crew.doorWaitTimer === undefined) {
                            crew.doorWaitTimer = 0;
                        }

                        // If timer not started, start it
                        if (crew.doorWaitTimer <= 0) {
                            crew.doorWaitTimer = 0.5; // 0.5 seconds wait
                        }

                        // Decrement timer
                        crew.doorWaitTimer -= 1 / 60;

                        // If timer finished, open door and proceed
                        if (crew.doorWaitTimer <= 0) {
                            this.ship.layout[nextNode.y][nextNode.x] = 5;
                            crew.doorWaitTimer = 0;
                            this.notify();
                        } else {
                            // Still waiting, skip movement
                            continue;
                        }
                    }

                    if (distance < 3) {
                        crew.path.shift();

                        if (crew.path.length === 0) {
                            crew.x = crew.targetX;
                            crew.y = crew.targetY;

                            if (crew.state === 'moving') {
                                crew.state = 'working';
                                crew.targetX = null;
                                crew.targetY = null;
                            } else if (crew.state === 'wandering') {
                                crew.state = 'idle';
                                crew.targetX = null;
                                crew.targetY = null;
                                crew.wanderTimer = 2 + Math.random() * 3;
                            }
                        }
                    } else {
                        const moveX = (dx / distance) * crew.speed;
                        const moveY = (dy / distance) * crew.speed;
                        crew.x += moveX;
                        crew.y += moveY;
                    }
                }
            }
        }
    }

    getRandomWalkablePosition() {
        const walkableTiles = [];
        for (let y = 0; y < this.ship.layout.length; y++) {
            for (let x = 0; x < this.ship.layout[y].length; x++) {
                if (this.isWalkable(x, y)) {
                    walkableTiles.push({ x, y });
                }
            }
        }

        if (walkableTiles.length > 0) {
            return walkableTiles[Math.floor(Math.random() * walkableTiles.length)];
        }
        return null;
    }

    smoothPath(path) {
        if (path.length <= 2) return path;

        const smoothed = [path[0]];

        for (let i = 1; i < path.length - 1; i++) {
            const prev = path[i - 1];
            const current = path[i];
            const next = path[i + 1];

            const dx1 = current.x - prev.x;
            const dy1 = current.y - prev.y;
            const dx2 = next.x - current.x;
            const dy2 = next.y - current.y;

            // Check if current tile is a door
            const isDoor = this.ship.layout[current.y][current.x] === 4;

            if ((dx1 !== dx2 || dy1 !== dy2) || isDoor) {
                smoothed.push(current);
            }
        }

        smoothed.push(path[path.length - 1]);

        return smoothed;
    }

    findPath(startX, startY, targetX, targetY) {
        const openList = [];
        const closedList = new Set();

        const startNode = {
            x: startX,
            y: startY,
            g: 0,
            h: this.heuristic(startX, startY, targetX, targetY),
            f: 0,
            parent: null
        };
        startNode.f = startNode.g + startNode.h;

        openList.push(startNode);

        while (openList.length > 0) {
            openList.sort((a, b) => a.f - b.f);
            const current = openList.shift();

            if (current.x === targetX && current.y === targetY) {
                return this.reconstructPath(current);
            }

            closedList.add(`${current.x},${current.y}`);

            const neighbors = [
                { x: current.x + 1, y: current.y },
                { x: current.x - 1, y: current.y },
                { x: current.x, y: current.y + 1 },
                { x: current.x, y: current.y - 1 }
            ];

            for (const neighbor of neighbors) {
                const key = `${neighbor.x},${neighbor.y}`;

                if (closedList.has(key)) continue;
                if (!this.isWalkable(neighbor.x, neighbor.y)) continue;

                const g = current.g + 1;
                const h = this.heuristic(neighbor.x, neighbor.y, targetX, targetY);
                const f = g + h;

                const existingNode = openList.find(n => n.x === neighbor.x && n.y === neighbor.y);

                if (existingNode) {
                    if (g < existingNode.g) {
                        existingNode.g = g;
                        existingNode.f = f;
                        existingNode.parent = current;
                    }
                } else {
                    openList.push({
                        x: neighbor.x,
                        y: neighbor.y,
                        g: g,
                        h: h,
                        f: f,
                        parent: current
                    });
                }
            }
        }

        return [];
    }

    heuristic(x1, y1, x2, y2) {
        return Math.abs(x1 - x2) + Math.abs(y1 - y2);
    }

    isWalkable(x, y) {
        if (!this.ship.layout[y] || !this.ship.layout[y][x]) return false;

        const tile = this.ship.layout[y][x];
        // Walkable: Floor (2), Slot (3), Closed Door (4), Open Door (5)
        return tile === 2 || tile === 3 || tile === 4 || tile === 5;
    }

    reconstructPath(node) {
        const path = [];
        let current = node;

        while (current.parent) {
            path.unshift({ x: current.x, y: current.y });
            current = current.parent;
        }


        return path;
    }

    // Travel System Methods
    travelToSystem(systemId) {
        const targetSystem = this.galaxy.find(s => s.id === systemId);
        if (!targetSystem) {
            return { success: false, message: 'System not found' };
        }

        // Calculate distance
        const dx = targetSystem.x - this.currentSystem.x;
        const dy = targetSystem.y - this.currentSystem.y;
        const distance = Math.sqrt(dx * dx + dy * dy);

        // Check jump range
        if (distance > this.ship.jumpRange) {
            return {
                success: false,
                message: `Target system is ${distance.toFixed(1)} LY away. Your jump drive can only reach ${this.ship.jumpRange} LY.`
            };
        }

        // Execute jump
        this.currentSystem = targetSystem;
        this.currentSystem.visited = true;

        // Select first planet with station, or first planet
        const stationPlanet = targetSystem.planets.find(p => p.hasStation);
        this.currentPlanet = stationPlanet || targetSystem.planets[0];

        this.saveGame();
        this.notify();

        return {
            success: true,
            message: `Jumped to ${targetSystem.name}. Now orbiting ${this.currentPlanet.name}.`
        };
    }

    travelToPlanet(planetId) {
        const targetPlanet = this.currentSystem.planets.find(p => p.id === planetId);
        if (!targetPlanet) {
            return { success: false, message: 'Planet not found in current system' };
        }

        // Check if same planet
        if (this.currentPlanet && this.currentPlanet.id === planetId) {
            return { success: false, message: 'Already at this planet' };
        }

        // Check fuel
        const fuelCost = 5;
        if (this.ship.fuel < fuelCost) {
            return {
                success: false,
                message: `Insufficient fuel. Need ${fuelCost} units, have ${this.ship.fuel}.`
            };
        }

        // Consume fuel
        this.ship.fuel -= fuelCost;
        this.currentPlanet = targetPlanet;

        this.saveGame();
        this.notify();

        return {
            success: true,
            message: `Traveled to ${targetPlanet.name}. Fuel: ${this.ship.fuel}/${this.ship.maxFuel}`
        };
    }
}
