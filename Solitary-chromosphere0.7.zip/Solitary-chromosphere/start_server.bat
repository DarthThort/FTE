@echo off
echo Starting Local Game Server...
echo Open http://localhost:8000 in your browser.
python -m http.server 8000
pause
