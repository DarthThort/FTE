class Effect {
    constructor(x, y, type = 'pulse') {
        this.x = x;
        this.y = y;
        this.type = type;
        this.life = 0.3; // Seconds
        this.maxLife = 0.3;
        this.size = 0;
    }

    update(dt) {
        this.life -= dt;
        if (this.type === 'pulse') {
            this.size += dt * 5; // Expand
        }
    }

    draw(renderer, cameraX, cameraY) {
        const alpha = this.life / this.maxLife;
        const color = `rgba(0, 255, 255, ${alpha})`; // Cyan pulse

        // Draw an expanding circle (ellipse in iso)
        // We can use the renderer's iso conversion but draw a custom path
        const pos = renderer.isoToScreen(this.x, this.y, 0, cameraX, cameraY);
        const ctx = renderer.ctx;

        ctx.save();
        ctx.strokeStyle = color;
        ctx.lineWidth = 2;
        ctx.beginPath();
        // Draw ellipse
        ctx.ellipse(pos.x, pos.y, this.size * 32, this.size * 16, 0, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
    }
}
