class Game {
    constructor(canvas) {
        this.input = new Input();
        this.renderer = new Renderer(canvas);
        this.sound = new Sound();
        this.lastTime = 0;

        this.currentLevel = 1;
        this.maxLevel = 10;

        this.map = new Map(50, 50);
        this.player = new Player(25, 25);
        this.enemies = [];
        this.items = [];
        this.effects = [];
        this.stairs = null;

        this.initLevel();

        this.uiHpVal = document.getElementById('hp-val');
        this.uiHpMax = document.getElementById('hp-max');
        this.uiLvlVal = document.getElementById('lvl-val');
        this.uiFloorVal = document.getElementById('floor-val');
        this.uiMessages = document.getElementById('messages');

        this.statsMenu = document.getElementById('stats-menu');
        this.statsMenuOpen = false;
        this.initStatsMenu();

        this.inventoryMenu = document.getElementById('inventory-menu');
        this.inventoryMenuOpen = false;
    }

    initStatsMenu() {
        const buttons = document.querySelectorAll('.stat-btn');
        buttons.forEach(btn => {
            btn.addEventListener('click', () => {
                const stat = btn.getAttribute('data-stat');
                if (this.player.addStatPoint(stat)) {
                    this.updateStatsMenu();
                    this.sound.playAttack();
                }
            });
        });
    }

    updateStatsMenu() {
        document.getElementById('stat-points').innerText = this.player.statPoints;

        const strBonus = this.player.stats.strength - this.player.baseStats.strength;
        const dexBonus = this.player.stats.dexterity - this.player.baseStats.dexterity;
        const vitBonus = this.player.stats.vitality - this.player.baseStats.vitality;
        const intBonus = this.player.stats.intelligence - this.player.baseStats.intelligence;

        document.getElementById('stat-str').innerText = this.player.baseStats.strength + (strBonus > 0 ? ` (+${strBonus})` : '');
        document.getElementById('stat-dex').innerText = this.player.baseStats.dexterity + (dexBonus > 0 ? ` (+${dexBonus})` : '');
        document.getElementById('stat-vit').innerText = this.player.baseStats.vitality + (vitBonus > 0 ? ` (+${vitBonus})` : '');
        document.getElementById('stat-int').innerText = this.player.baseStats.intelligence + (intBonus > 0 ? ` (+${intBonus})` : '');

        const buttons = document.querySelectorAll('.stat-btn');
        buttons.forEach(btn => {
            btn.disabled = this.player.statPoints <= 0;
        });
    }

    toggleStatsMenu() {
        this.statsMenuOpen = !this.statsMenuOpen;
        this.statsMenu.style.display = this.statsMenuOpen ? 'flex' : 'none';
        if (this.statsMenuOpen) {
            this.updateStatsMenu();
        }
    }

    toggleInventoryMenu() {
        this.inventoryMenuOpen = !this.inventoryMenuOpen;
        this.inventoryMenu.style.display = this.inventoryMenuOpen ? 'flex' : 'none';
        if (this.inventoryMenuOpen) {
            this.updateInventoryMenu();
        }
    }

    updateInventoryMenu() {
        this.updateEquipmentSlot('weapon', this.player.equipment.weapon);
        this.updateEquipmentSlot('armor', this.player.equipment.armor);
        this.updateEquipmentSlot('helmet', this.player.equipment.helmet);
    }

    updateEquipmentSlot(slotName, item) {
        const slotElement = document.getElementById(`slot-${slotName}`);

        if (!item) {
            slotElement.innerHTML = '<div class="empty-slot">Vacío</div>';
        } else {
            let statsHtml = '';
            for (let stat in item.stats) {
                const value = item.stats[stat];
                const statLabel = stat.charAt(0).toUpperCase() + stat.slice(1);
                statsHtml += `<div class="stat-bonus">${statLabel}: ${value}</div>`;
            }

            slotElement.innerHTML = `
                <div class="item-equipped">
                    <div class="item-name">${item.name}</div>
                    <div class="item-stats">${statsHtml}</div>
                </div>
            `;
        }
    }

    initLevel() {
        this.enemies = [];
        this.items = [];

        const enemyCount = 10 + this.currentLevel * 2;
        this.spawnEnemies(enemyCount);

        if (this.currentLevel < this.maxLevel) {
            this.stairs = this.map.spawnStairs();
        } else {
            this.stairs = null;
        }
    }

    spawnEnemies(count) {
        const positions = this.map.spawnEnemies(count);
        positions.forEach(pos => {
            if (Math.hypot(pos.x - this.player.x, pos.y - this.player.y) > 5) {
                this.enemies.push(new Enemy(pos.x, pos.y));
            }
        });

        const bossCount = this.currentLevel === this.maxLevel ? 1 : Math.floor(this.currentLevel / 3);
        for (let i = 0; i < bossCount; i++) {
            const bossPos = this.map.spawnEnemies(1)[0];
            this.enemies.push(new Enemy(bossPos.x, bossPos.y, 'boss'));
        }
    }

    start() {
        requestAnimationFrame((time) => this.loop(time));
    }

    loop(time) {
        const dt = (time - this.lastTime) / 1000;
        this.lastTime = time;

        this.update(dt);
        this.draw();
        this.updateUI();

        this.input.update();
        requestAnimationFrame((time) => this.loop(time));
    }

    update(dt) {
        if (this.player.hp <= 0) {
            this.showMessage('GAME OVER! Refresh to restart.');
            return;
        }

        if (this.input.isPressed('KeyP')) {
            this.toggleStatsMenu();
        }

        if (this.input.isPressed('KeyI')) {
            this.toggleInventoryMenu();
        }

        if (this.statsMenuOpen || this.inventoryMenuOpen) {
            return;
        }

        const oldX = this.player.x;
        const oldY = this.player.y;

        this.player.update(dt, this.input);

        if (!this.map.isWalkable(this.player.x, this.player.y)) {
            this.player.x = oldX;
            this.player.y = oldY;
        }

        if (this.stairs) {
            const distToStairs = Math.hypot(this.player.x - this.stairs.x, this.player.y - this.stairs.y);
            if (distToStairs < 1) {
                this.nextLevel();
            }
        }

        this.enemies.forEach(enemy => {
            enemy.update(dt, this.player, this.map);
        });

        this.effects.forEach(effect => effect.update(dt));
        this.effects = this.effects.filter(e => e.life > 0);

        if (this.input.isPressed('Space')) {
            this.playerAttack();
        }

        let nearbyItem = null;
        this.items.forEach((item) => {
            const dist = Math.hypot(item.x - this.player.x, item.y - this.player.y);
            if (dist < 1.5) {
                nearbyItem = item;
            }
        });

        this.updateItemComparison(nearbyItem);

        if (this.input.isPressed('KeyE') && nearbyItem) {
            this.player.equip(nearbyItem);
            this.items = this.items.filter(i => i !== nearbyItem);
            this.showMessage(`Equipado ${nearbyItem.name}!`);
            this.sound.playAttack();
        }

        this.enemies = this.enemies.filter(e => e.stats.hp > 0);

        if (this.currentLevel === this.maxLevel && this.enemies.length === 0) {
            this.showMessage('YOU WIN! Final boss defeated!');
        }
    }

    updateItemComparison(newItem) {
        const panel = document.getElementById('item-comparison');

        if (!newItem) {
            panel.style.display = 'none';
            return;
        }

        const equippedItem = this.player.equipment[newItem.type];

        let newItemStatsHtml = '';
        for (let stat in newItem.stats) {
            const value = newItem.stats[stat];
            const statLabel = stat.charAt(0).toUpperCase() + stat.slice(1);

            let diff = '';
            let valueClass = '';
            if (equippedItem && equippedItem.stats[stat] !== undefined) {
                const equippedValue = equippedItem.stats[stat];
                const difference = value - equippedValue;
                if (difference > 0) {
                    diff = `<span class="stat-diff positive">(+${difference})</span>`;
                    valueClass = 'better';
                } else if (difference < 0) {
                    diff = `<span class="stat-diff negative">(${difference})</span>`;
                    valueClass = 'worse';
                }
            }

            newItemStatsHtml += `
                <div class="comparison-stat">
                    <span class="stat-label">${statLabel}:</span>
                    <span>
                        <span class="stat-value ${valueClass}">${value}</span>
                        ${diff}
                    </span>
                </div>
            `;
        }

        let equippedHtml = '';
        if (equippedItem) {
            let equippedStatsHtml = '';
            for (let stat in equippedItem.stats) {
                const value = equippedItem.stats[stat];
                const statLabel = stat.charAt(0).toUpperCase() + stat.slice(1);
                equippedStatsHtml += `
                    <div class="comparison-stat">
                        <span class="stat-label">${statLabel}:</span>
                        <span class="stat-value">${value}</span>
                    </div>
                `;
            }

            const typeLabel = equippedItem.type.charAt(0).toUpperCase() + equippedItem.type.slice(1);
            equippedHtml = `
                <div class="comparison-title">${equippedItem.name}</div>
                <div class="comparison-type">${typeLabel} Equipado</div>
                <div class="comparison-stats">${equippedStatsHtml}</div>
            `;
        } else {
            equippedHtml = '<div class="empty-slot-text">Sin equipar</div>';
        }

        const newTypeLabel = newItem.type.charAt(0).toUpperCase() + newItem.type.slice(1);

        panel.innerHTML = `
            <div class="comparison-header">COMPARAR EQUIPO</div>
            <div class="comparison-container">
                <div class="comparison-item new-item">
                    <div class="comparison-title">${newItem.name}</div>
                    <div class="comparison-type">${newTypeLabel} Nuevo</div>
                    <div class="comparison-stats">${newItemStatsHtml}</div>
                </div>
                <div class="comparison-item">
                    ${equippedHtml}
                </div>
            </div>
            <div class="comparison-hint">Presiona E para equipar</div>
        `;

        panel.style.display = 'block';
    }

    nextLevel() {
        this.currentLevel++;
        if (this.currentLevel > this.maxLevel) {
            this.currentLevel = this.maxLevel;
            return;
        }

        this.showMessage(`Level ${this.currentLevel}!`);

        this.player.x = 25;
        this.player.y = 25;

        this.map = new Map(50, 50);
        this.initLevel();
    }

    playerAttack() {
        this.sound.playAttack();
        this.effects.push(new Effect(this.player.x, this.player.y, 'pulse'));

        const range = 2;
        this.enemies.forEach(enemy => {
            const dist = Math.hypot(enemy.x - this.player.x, enemy.y - this.player.y);
            if (dist <= range) {
                let dmg = this.player.stats.strength;
                if (this.player.equipment.weapon) dmg += this.player.equipment.weapon.stats.damage || 0;

                enemy.stats.hp -= dmg;
                this.sound.playHit();
                console.log(`Hit enemy! HP: ${enemy.stats.hp}`);

                const dx = enemy.x - this.player.x;
                const dy = enemy.y - this.player.y;
                enemy.x += dx * 0.5;
                enemy.y += dy * 0.5;

                if (enemy.stats.hp <= 0) {
                    this.onEnemyDeath(enemy);
                }
            }
        });
    }

    onEnemyDeath(enemy) {
        this.player.gainXp(enemy.stats.xpValue);
        this.showMessage(`Killed ${enemy.type}! +${enemy.stats.xpValue} XP`);

        if (Math.random() > 0.5) {
            const item = Item.generate(this.player.level);
            item.x = enemy.x;
            item.y = enemy.y;
            this.items.push(item);
        }
    }

    updateUI() {
        this.uiHpVal.innerText = Math.floor(this.player.hp);
        this.uiHpMax.innerText = this.player.maxHp;
        this.uiLvlVal.innerText = this.player.level;
        this.uiFloorVal.innerText = this.currentLevel;
    }

    showMessage(msg) {
        this.uiMessages.innerText = msg;
        setTimeout(() => {
            if (this.uiMessages.innerText === msg) this.uiMessages.innerText = '';
        }, 2000);
    }

    draw() {
        this.renderer.clear();

        const cameraX = this.player.x;
        const cameraY = this.player.y;

        this.map.draw(this.renderer, cameraX, cameraY, this.stairs);

        this.items.forEach(item => item.draw(this.renderer, cameraX, cameraY));
        this.enemies.forEach(enemy => enemy.draw(this.renderer, cameraX, cameraY));

        this.player.draw(this.renderer, cameraX, cameraY);

        this.effects.forEach(effect => effect.draw(this.renderer, cameraX, cameraY));
    }
}
