class Renderer {
    constructor(canvas) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this.width = canvas.width;
        this.height = canvas.height;
        this.tileSize = 32; // Size of a tile in "world" pixels

        // Resize handling
        window.addEventListener('resize', () => this.resize());
        this.resize();
    }

    resize() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
        this.width = this.canvas.width;
        this.height = this.canvas.height;
        this.ctx.imageSmoothingEnabled = false; // Pixel art style
    }

    clear() {
        this.ctx.fillStyle = '#050505';
        this.ctx.fillRect(0, 0, this.width, this.height);
    }

    // Convert world coordinates (grid) to screen coordinates (isometric)
    // x, y are grid coordinates. z is height (optional)
    // cameraX, cameraY are the center of the view in world coordinates
    isoToScreen(x, y, z = 0, cameraX = 0, cameraY = 0) {
        // Isometric projection formula
        // screenX = (x - y) * tileWidth / 2
        // screenY = (x + y) * tileHeight / 2

        const tileWidth = this.tileSize * 2;
        const tileHeight = this.tileSize;

        // Calculate offset based on camera position
        // We want cameraX, cameraY to be at the center of the screen (width/2, height/2)

        // World position of the point
        const worldX = (x - y) * (tileWidth / 2);
        const worldY = (x + y) * (tileHeight / 2) - (z * tileHeight);

        // World position of the camera
        const camWorldX = (cameraX - cameraY) * (tileWidth / 2);
        const camWorldY = (cameraX + cameraY) * (tileHeight / 2);

        const screenX = worldX - camWorldX + this.width / 2;
        const screenY = worldY - camWorldY + this.height / 2;

        return { x: screenX, y: screenY };
    }

    drawTile(x, y, color, cameraX, cameraY) {
        const pos = this.isoToScreen(x, y, 0, cameraX, cameraY);
        const tileWidth = this.tileSize * 2;
        const tileHeight = this.tileSize;

        // Optimization: Don't draw if off screen
        // Simple bounding box check
        if (pos.x < -tileWidth || pos.x > this.width + tileWidth ||
            pos.y < -tileHeight || pos.y > this.height + tileHeight) {
            return;
        }

        this.ctx.fillStyle = color;
        this.ctx.beginPath();
        this.ctx.moveTo(pos.x, pos.y);
        this.ctx.lineTo(pos.x + tileWidth / 2, pos.y + tileHeight / 2);
        this.ctx.lineTo(pos.x, pos.y + tileHeight);
        this.ctx.lineTo(pos.x - tileWidth / 2, pos.y + tileHeight / 2);
        this.ctx.closePath();
        this.ctx.fill();

        // Border for grid effect
        this.ctx.strokeStyle = '#111';
        this.ctx.stroke();
    }

    drawRectIso(x, y, width, height, color, z = 0, cameraX, cameraY) {
        const pos = this.isoToScreen(x, y, z, cameraX, cameraY);
        // Simple representation for entities for now
        this.ctx.fillStyle = color;
        // Draw a simple box standing up
        const w = this.tileSize;
        const h = this.tileSize * 1.5; // Taller than a tile

        this.ctx.fillRect(pos.x - w / 2, pos.y - h, w, h);
    }
}
