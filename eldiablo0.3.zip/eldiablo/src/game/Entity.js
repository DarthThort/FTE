class Entity {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.z = 0;
        this.width = 0.8;
        this.height = 0.8;
        this.color = '#fff';
    }

    update(dt) {
        // Base update
    }

    draw(renderer, cameraX, cameraY) {
        renderer.drawRectIso(this.x, this.y, this.width, this.height, this.color, this.z, cameraX, cameraY);
    }
}
