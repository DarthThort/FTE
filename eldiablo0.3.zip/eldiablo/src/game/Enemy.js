class Enemy extends Entity {
    constructor(x, y, type = 'minion') {
        super(x, y);
        this.type = type;
        this.color = '#f00';
        this.speed = 2;
        this.aggroRange = 8;
        this.attackCooldown = 0;
        this.attackSpeed = 1.5;

        this.stats = {
            hp: 20,
            maxHp: 20,
            damage: 5,
            xpValue: 10
        };

        if (type === 'boss') {
            this.color = '#90f';
            this.width = 1.5;
            this.height = 1.5;
            this.stats.hp = 100;
            this.stats.maxHp = 100;
            this.stats.damage = 15;
            this.stats.xpValue = 100;
            this.speed = 3;
            this.attackSpeed = 1.0;
        }
    }

    update(dt, player, map) {
        if (this.attackCooldown > 0) {
            this.attackCooldown -= dt;
        }

        const dist = Math.hypot(player.x - this.x, player.y - this.y);

        if (dist < this.aggroRange) {
            if (dist > 0.8) {
                const dx = player.x - this.x;
                const dy = player.y - this.y;

                const len = Math.sqrt(dx * dx + dy * dy);
                const moveX = (dx / len) * this.speed * dt;
                const moveY = (dy / len) * this.speed * dt;

                if (map.isWalkable(this.x + moveX, this.y)) {
                    this.x += moveX;
                }
                if (map.isWalkable(this.x, this.y + moveY)) {
                    this.y += moveY;
                }
            } else {
                if (this.attackCooldown <= 0) {
                    this.attack(player);
                    this.attackCooldown = this.attackSpeed;
                }
            }
        }
    }

    attack(player) {
        player.takeDamage(this.stats.damage);
    }
}
