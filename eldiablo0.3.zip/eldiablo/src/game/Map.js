class Map {
    constructor(width, height) {
        this.width = width;
        this.height = height;
        this.tiles = [];
        this.generate();
    }

    generate() {
        for (let x = 0; x < this.width; x++) {
            this.tiles[x] = [];
            for (let y = 0; y < this.height; y++) {
                if (x === 0 || x === this.width - 1 || y === 0 || y === this.height - 1) {
                    this.tiles[x][y] = 1;
                } else {
                    this.tiles[x][y] = Math.random() > 0.9 ? 1 : 0;
                }
            }
        }
    }

    spawnEnemies(count) {
        const enemies = [];
        for (let i = 0; i < count; i++) {
            let x, y;
            do {
                x = Math.floor(Math.random() * this.width);
                y = Math.floor(Math.random() * this.height);
            } while (!this.isWalkable(x, y));

            enemies.push({ x, y });
        }
        return enemies;
    }

    spawnStairs() {
        let x, y;
        do {
            x = Math.floor(Math.random() * this.width);
            y = Math.floor(Math.random() * this.height);
        } while (!this.isWalkable(x, y));

        return { x, y };
    }

    draw(renderer, cameraX, cameraY, stairsPos) {
        for (let x = 0; x < this.width; x++) {
            for (let y = 0; y < this.height; y++) {
                const tile = this.tiles[x][y];
                const color = tile === 1 ? '#444' : '#222';

                if (stairsPos && Math.floor(stairsPos.x) === x && Math.floor(stairsPos.y) === y) {
                    renderer.drawTile(x, y, '#0a0', cameraX, cameraY);
                } else if (tile === 1) {
                    renderer.drawRectIso(x, y, 1, 1, '#555', 0, cameraX, cameraY);
                } else {
                    renderer.drawTile(x, y, color, cameraX, cameraY);
                }
            }
        }
    }

    isWalkable(x, y) {
        if (x < 0 || x >= this.width || y < 0 || y >= this.height) return false;
        return this.tiles[Math.floor(x)][Math.floor(y)] === 0;
    }
}
